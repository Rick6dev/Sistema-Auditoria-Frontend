# Configuración proyecto CCR-Auditoria-Backend

Este proyecto utiliza la version de Node 16

## Instalación

Con tal de instalar todas las  dependencias requeridas,esperar a que el proceso termine para continuar

```bash
npm install 
```

## Levantar el Sistema en Desarrollo
Levantar el proyecto de forma local  en el ordenador
```bash 
npm run dev
```
## Construir el proyecto
Con la  finalidad de construir el proyecto de typescript a javascript ejecutar el comando

```bash 
npm run build
```
## Autor

Ricardo Torres
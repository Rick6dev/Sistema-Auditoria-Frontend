import { Op } from "sequelize";
import Vacacion from "../models/VacacionModel";

export async function crearVacacion(solicitud: any, id: any) {
  const fechaActual = new Date();
  const añoActual = fechaActual.getFullYear();
  await Vacacion.create({
    fecha_inicio: solicitud.fecha_desde,
    fecha_reingreso: solicitud.fecha_reintegro,
    fecha_culminacion: solicitud.fecha_hasta,
    id_auditor_responsable: id,
    year: añoActual,
  });

  return;
}

export async function deleteVacacion(solicitud: any) {
  const fechaActual = new Date();
  await Vacacion.destroy({
    where: {
      id_vacacion: solicitud.id_vacacion,
      fecha_culminacion: {
        [Op.gt]: fechaActual,
      },
    },
  });

  return;
}

export async function actualizarVacaciones(
  intraVacaciones: any,
  vacaciones: any,
  id: any
) {
  try {

    // Iterar sobre los datos de intraVacaciones
    for (const solicitud of intraVacaciones) {
      // Buscar la vacación existente
      const [vacacion, created]: any = await Vacacion.findOrCreate({
        where: { id_vacacion: solicitud.id_vacacion },
        defaults: {
          fecha_inicio: solicitud.fecha_desde,
          fecha_reingreso: solicitud.fecha_reintegro,
          fecha_culminacion: solicitud.fecha_hasta,
          id_auditor_responsable: id,
          year: new Date().getFullYear(),
        },
      });

      // Si la vacación ya existía, actualizarla
      if (!created) {
        await vacacion.update(
          {
            fecha_inicio: solicitud.fecha_desde,
            fecha_reingreso: solicitud.fecha_reintegro,
            fecha_culminacion: solicitud.fecha_hasta,
            id_auditor_responsable: id,
            year: new Date().getFullYear(),
          },
          {
            where: {
              id_vacacion: vacaciones[0].id_vacacion,
            },
          }
        );
      }
    }
  } catch (error) {
    console.error("Error al actualizar vacaciones:", error);
  }
}

import GrcModel from "../models/GrcModel";
import VpeModel from "../models/VPEModel";
import VpModel from "../models/VPModel";

export async function ExtracGrc(): Promise<string> {
  const gerencias: any = await GrcModel.findAll({
    include: [
      {
        model: VpModel,
        as: "VP", // Usa el alias correcto
        attributes: ["nombre_vp"],
        include: [
          {
            model: VpeModel,
            as: "VPE", // Usa el alias correcto
            attributes: ["id_vpe", "nombre_vpe"],
          },
        ],
      },
    ],
  });
  return gerencias;
}
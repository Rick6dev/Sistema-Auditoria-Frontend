import { Sequelize } from "sequelize";
import Hallazgo from "../module/hallazgo/models/HallazgoModel";
import InformeAuditoria from "../module/informeAuditoria/models/InformeAuditoria";
import NvlRiesgoModel from "../module/hallazgo/models/NvlRiesgoModel";
import RsgModel from "../module/hallazgo/models/RsgModel";
import Auditor from "../auth/models/AuditModel";
import GerenciaResponsableHistorico from "../models/GrcHistoricoModel";

export async function reportGerencia(id: any): Promise<string> {
  let hallazgos: any = await Hallazgo.findAll({
    where: {
      id_gerencia: id,
      cerrado: false,
    },
    include: [
      {
        model: InformeAuditoria,
        attributes: ["nombre_informe", "cod_informe", "trimestre"],
      },
      {
        model: NvlRiesgoModel,
        attributes: ["nombre_nivel_riesgo" as "nivelRiesgo"],
      },
      {
        model: RsgModel,
        attributes: ["nombre_riesgo_asociado"],
      },
      {
        model: Auditor,
        attributes: ["id_auditor_responsable", "nombre", "apellido"],
      },
      {
        model: GerenciaResponsableHistorico,
        attributes: ["id_gerencia_historico", "gerencia_historico"],
      },
    ],
  });

  return hallazgos;
}

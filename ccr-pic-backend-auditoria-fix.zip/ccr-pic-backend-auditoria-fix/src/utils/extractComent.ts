import Auditor from "../auth/models/AuditModel";
import EmpleadosModel from "../auth/models/EmpleadoModel";

export async function ExtractEmpleadoComentr(): Promise<string> {
  const empleados: any = await Auditor.findAll({
    attributes: ["id_auditor_responsable", "nombre", "apellido"],
  });
  return empleados;
}

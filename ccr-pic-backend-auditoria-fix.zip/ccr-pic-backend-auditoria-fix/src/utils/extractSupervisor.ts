import IntraSupervisor from "../auth/models/SupervisorModel";
export async function ExtracSup(): Promise<string> {
  const supervisor: any = await IntraSupervisor.findAll({
    attributes: ["id_supervisor", "ci_supervisor", "nombre_sup1", "apellido_sup1", "id_cargo", "id_dpto", "id_gerencia", "id_vp", "id_vpe", "id_pe", "id_status"],
    where: {
      id_status: 1,
    },
  });
  return supervisor

}

export async function ExtracSupOneGAT(): Promise<string> {


  const supervisor: any = await IntraSupervisor.findAll({
    attributes: ["id_supervisor", "ci_supervisor", "nombre_sup1", "apellido_sup1", "id_cargo", "id_dpto", "id_gerencia", "id_vp", "id_vpe", "id_pe", "id_status"],
    where: {
      id_gerencia: process.env.GAT_ID, // id  de  Gerente  de  GAT
    },
  });
  return supervisor

}


export async function ExtracSupOneGAOF(): Promise<string> {
  const supervisor: any = await IntraSupervisor.findAll({
    attributes: ["id_supervisor", "ci_supervisor", "nombre_sup1", "apellido_sup1", "id_cargo", "id_dpto", "id_gerencia", "id_vp", "id_vpe", "id_pe", "id_status"],
    where: {
      id_gerencia: process.env.GAOF_ID, //Id  de la Gerencia de GAOF
    },
  });

  return supervisor;

}

export async function ExtracSupVp(): Promise<string> {
  const supervisor: any = await IntraSupervisor.findAll({
    attributes: ["id_supervisor", "ci_supervisor", "nombre_sup1", "apellido_sup1", "id_cargo", "id_dpto", "id_gerencia", "id_vp", "id_vpe", "id_pe", "id_status"],
    where: {
      id_vp: process.env.VP_AUDITORIA_ID //Id del  VP  de Auditoria 
    },
  });
  return supervisor

}
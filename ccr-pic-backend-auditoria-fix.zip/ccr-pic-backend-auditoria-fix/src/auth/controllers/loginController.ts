import { Response, Request } from "express";
import IntraSupervisor from "../models/SupervisorModel";
import { ExtracSup } from "../../utils/extractSupervisor";
import {
  ExtractUsuario,
  ExtractUsuarioAuditor,
  formatEmail,
} from "../../utils/extractAuditor";
import EmpleadosModel from "../models/EmpleadoModel";

import * as jwt from "jsonwebtoken";
import keys from "../../config/keys";
import { configLdap } from "../../config/activedirectory";
import ActiveDirectory from "activedirectory2";
import Auditor from "../models/AuditModel";
import { determineUserAccess } from "../../utils/determineUserAccess";
import Rol from "../../models/RolModel";
import SGAI_LOGSModel from "../../logs/models/SGAI_LOGS";
import { createLogs } from "../../logs/controllers/SGAIController";

class LoginController {
  public async loginValidate(req: Request, res: Response): Promise<void> {
    try {
      const { username } = req.body;
      let UserAud: any = {
        nombre: "",
        apellido: "",
      };
      let mail = username;
      let noUser = false;
      mail = formatEmail(mail);
      const nombre = mail.split(".")[0];
      const apellido = mail.split(".")[1].split("@")[0];
      let countOptions: any = {
        where: { mail: mail },
      };
      let count2: any = await EmpleadosModel.count(countOptions);
      if (count2 === 0) {
        noUser = true;
        res.status(203).json({
          noAccess: noUser,
          message: "El usuario ingresado no se encuentra en la bases de datos",
        });
      } else {
        let userF: any = await ExtractUsuario(mail);
        const { rol, user, areaTrabajo, noUser } = await determineUserAccess(
          username
        );

        const role: any = await Rol.findOne({
          where: {
            id_rol: rol,
          },
        });
        if (noUser) {
          res.status(203).json({
            noAccess: noUser,
            message: "No tienes los permisos  para acceder",
          });
        } else {
          let count: number = await Auditor.count({
            where: {
              mail: mail,
            },
          });
          if (count == 0) {
            await Auditor.create({
              nombre: nombre,
              apellido: apellido,
              mail: mail,
              ci_empleado: user[0].ci_empleado,
            });
          }
          UserAud = await ExtractUsuarioAuditor(mail);
          const token = jwt.sign(
            {
              userId: UserAud[0].id_auditor_responsable,
              userNombre: `${UserAud[0].nombre} ${UserAud[0].apellido} `,
              message: ` Bienvenido ${role.rol} ${UserAud[0].nombre} ${UserAud[0].apellido}, tu área es ${areaTrabajo} `,
              role: role.id_rol,
              namerole: role.rol,
              areaTrabajo: areaTrabajo,
              ci_empleado: UserAud[0].ci_empleado,
            },
            keys.adminData.SECRET_TOKEN,
            { expiresIn: "2h" }
          );

          createLogs(token, 1);
          res.status(200).json(token);
        }
      }
    } catch (error) {
      res.status(500).json({
        noAccess: true,
        message: `Se ha producido un error inesperado . Por favor, póngase en contacto con el administrador del sitio. ${error}`,
      });
    }
  }
  public async getEmpleado(req: Request, res: Response): Promise<void> {
    try {
      const supervisor: any = await ExtracSup();
      if (supervisor.length === 0) {
        res.status(204).json({ message: "No existe este supervisor" });
      } else {
        res.status(200).json(supervisor);
      }
    } catch (error) {
      res
        .status(500)
        .json({ message: `Error  en el servidor  al solicitar  un usuario ` });
    }
  }

  public async logOut(req: Request, res: Response): Promise<void> {
    try {
      const token: any = req.params.token;
      createLogs(token, 2);
      res.status(201).json({ text: "Session culminada sastisfactoriamente" });
    } catch (error) {
      res.status(500).json({
        noAccess: true,
        message: `Se ha producido un error inesperado . Por favor, póngase en contacto con el administrador del sitio. ${error}`,
      });
    }
  }
}

export const loginController = new LoginController();

import { auditSequelize } from "../../../database";
import Auditor from "../../../auth/models/AuditModel";
import EstadoReq from "./EstadoReqModel";
import GerenciaAuditoria from "../../../models/GrcAudit";
import InformeAuditoria from "../../../module/informeAuditoria/models/InformeAuditoria";

const { DataTypes } = require("sequelize");

const Requerimiento = auditSequelize.define(
  "requerimiento",
  {
    id_requerimiento: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false,
    },
    id_informe_auditoria: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    detalle_requerimiento: {
      type: DataTypes.STRING(600),
      allowNull: false,
    },
    id_auditor_responsable: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    id_gerencia_responsable: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    id_gerencia_encargada: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    fecha_solicitud: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: DataTypes.NOW,
    },
    fecha_devolucion: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    fecha_culminacion: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    id_estado_requerimiento: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 1,
    },
    cantidad_devoluciones: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0,
    },
    current_year: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    nombre_responsable: {
      type: DataTypes.STRING(200),
      allowNull: false,
    },
    apellido_responsable: {
      type: DataTypes.STRING(200),
      allowNull: false,
    },
  },
  {
    freezeTableName: true,
    timestamps: false,
  }
);

// Definir relaciones (si es necesario)

Requerimiento.belongsTo(Auditor, {
  foreignKey: "id_auditor_responsable",
});
Requerimiento.belongsTo(InformeAuditoria, {
  foreignKey: "id_informe_auditoria",
});
Requerimiento.belongsTo(EstadoReq, {
  foreignKey: "id_estado_requerimiento",
});
Requerimiento.belongsTo(GerenciaAuditoria, {
  foreignKey: "id_gerencia_encargada",
});

export default Requerimiento;

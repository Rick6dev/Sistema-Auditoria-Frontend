import { DataTypes, Sequelize } from "sequelize";
import { auditSequelize } from "../../../database";

const EstadoReq = auditSequelize.define(
  "estado_requirimiento",
  {
    id_estado_requerimiento: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    nombre_estado_requerimiento: {
      type: DataTypes.STRING(200),
      allowNull: false,
    },
  },
  {
    freezeTableName: true,
    timestamps: false,
  }
);

export default EstadoReq;

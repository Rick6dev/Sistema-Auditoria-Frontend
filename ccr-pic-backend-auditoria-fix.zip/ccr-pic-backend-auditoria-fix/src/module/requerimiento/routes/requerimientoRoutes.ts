import { Router } from "express";
import { requerimientoController } from "../controllers/requerimientoController";

class RequerimientoRoutes {
  public router: Router = Router();

  constructor() {
    this.config();
  }

  config(): void {
    this.router.get(
      "/getRequerimiento",
      requerimientoController.getRequerimiento
    );
    this.router.put(
      "/updateRequerimientoStatus",
      requerimientoController.updateSolictudRequerimiento
    );
    this.router.get(
      "/getEstadoRequerimiento",
      requerimientoController.getEstadoRequerimiento
    );
    this.router.post(
      "/postRequerimiento",
      requerimientoController.createRequerimiento
    );
    this.router.put(
      "/updateRequerimiento",
      requerimientoController.updateRequerimiento
    );
    this.router.delete(
      "/deleteRequerimiento/:id",
      requerimientoController.deleteRequerimiento
    );

    this.router.get(
      "/getInformesAuditoria/",
      requerimientoController.getInformeAuditoria
    );
  }
}

const requerimientoRoutes = new RequerimientoRoutes();

export default requerimientoRoutes.router;

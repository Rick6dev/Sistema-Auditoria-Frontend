import { Request, Response } from "express";
import Requerimiento from "../models/RequerimientoModel";
import EstadoReq from "../models/EstadoReqModel";
import InformeAuditoria from "../../informeAuditoria/models/InformeAuditoria";
import Auditor from "../../../auth/models/AuditModel";
import GerenciaAuditoria from "../../../models/GrcAudit";
import { ExtracGrc } from "../../../utils/extractGrc";
import { Join, JoinReq } from "../../../utils/join";
import { createLogs } from "../../../logs/controllers/SGAIController";

class RequerimientoController {
  public async getEstadoRequerimiento(
    req: Request,
    res: Response
  ): Promise<void> {
    try {
      const requerimiento = await EstadoReq.findAll();
      if (requerimiento.length == 0) {
        res.status(204).json({
          message: "No existes estados  de  requerimiento registrado",
        });
      } else {
        res.status(200).json(requerimiento);
      }
    } catch (error) {
      res.status(500).json({
        message: `Se ha  producido un error en el  servidor  del  sistema  ${error}`,
      });
    }
  }

  public async getRequerimiento(req: Request, res: Response): Promise<void> {
    try {
      const gerencias = await ExtracGrc();
      // id_gerencia
      const requerimiento = await Requerimiento.findAll({
        include: [
          { model: InformeAuditoria },
          { model: Auditor },
          { model: EstadoReq },
          { model: GerenciaAuditoria },
        ],
      });

      const requerimientoData = await JoinReq(requerimiento, gerencias);
      if (requerimiento.length == 0) {
        res
          .status(204)
          .json({ message: "No existe ningun  requerimiento  registrado" });
      } else {
        res.status(200).json(requerimientoData);
      }
    } catch (error) {
      res.status(500).json({
        message: `Se ha producido un error  en el servidor. Contactar con el  administrador  del  sistema ${error}`,
      });
    }
  }

  public async createRequerimiento(req: Request, res: Response): Promise<void> {
    try {
      const fechaActual = new Date();
      const current_year = fechaActual.getFullYear();
      const {
        id_informe_auditoria,
        detalle_requerimiento,
        id_auditor_responsable,
        id_gerencia_responsable,
        id_gerencia_encargada,
        nombre_responsable,
        apellido_responsable,
      } = req.body;

      await Requerimiento.create({
        id_informe_auditoria,
        nombre_responsable,
        apellido_responsable,
        id_gerencia_encargada,
        id_gerencia_responsable,
        detalle_requerimiento,
        id_auditor_responsable,
        current_year: current_year,
      });
      const token2: any = req.headers?.authorization?.split(" ")[1];
      createLogs(token2, 15);

      res.status(201).json({ text: "Requerimiento creado sastifactoriamente" });
    } catch (error) {
      res.status(500).json({
        message: `Se ha producido un error  en el servidor. Contactar con el  administrador  del  sistema ${error}`,
      });
    }
  }

  public async updateRequerimiento(req: Request, res: Response): Promise<void> {
    try {
      let {
        id_estado_requerimiento,
        cantidad_devoluciones,
        nombre_responsable,
        apellido_responsable,
        id_requerimiento,
        fecha_devolucion,
        fecha_culminacion,
      } = req.body;

      await Requerimiento.update(
        {
          nombre_responsable,
          apellido_responsable,
          cantidad_devoluciones,
          id_estado_requerimiento,
          fecha_devolucion,
          fecha_culminacion,
        },
        {
          where: {
            id_requerimiento: id_requerimiento,
          },
        }
      );
      const token2: any = req.headers?.authorization?.split(" ")[1];
      createLogs(token2, 16);
      res.status(201).json({ text: "Requerimiento Actualizado correctamente" });
    } catch (error) {
      console.error(`Erro actualizando el  requrimiento ${error}`);
      res.status(500).json({
        message: `${error}`,
      });
    }
  }
  public async updateSolictudRequerimiento(
    req: Request,
    res: Response
  ): Promise<void> {
    try {
      let {
        apellido_responsable,
        nombre_responsable,
        detalle_requerimiento,
        id_requerimiento,
      } = req.body;

      await Requerimiento.update(
        {
          nombre_responsable,
          apellido_responsable,
          detalle_requerimiento,
        },
        {
          where: {
            id_requerimiento: id_requerimiento,
          },
        }
      );
      const token2: any = req.headers?.authorization?.split(" ")[1];
      createLogs(token2, 18);
      res.status(201).json({ text: "Requerimiento Actualizado correctamente" });
    } catch (error) {
      console.error(`Erro actualizando el  requrimiento ${error}`);
      res.status(500).json({
        message: `${error}`,
      });
    }
  }

  public async deleteRequerimiento(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      await Requerimiento.destroy({
        where: {
          id_requerimiento: id,
        },
      });
      const token2: any = req.headers?.authorization?.split(" ")[1];
      createLogs(token2, 17);
      res
        .status(201)
        .json({ text: "Requerimiento eliminado  sastisfactoriamente" });
    } catch (error) {
      res.status(500).json({
        message: `Se ha producido un error en el servidor ${error}`,
      });
    }
  }
  public async getInformeAuditoria(req: Request, res: Response): Promise<void> {
    try {
      const fechaActual = new Date();
      const current_year = fechaActual.getFullYear();
      const informes: any = await InformeAuditoria.findAll({
        where: {
          created_year: current_year,
        },
      });
      if (informes.length == 0) {
        res.status(204).json({
          message: "No existe ningun  informe de  auditoría",
        });
      } else {
        res.status(200).json(informes);
      }
    } catch (error) {
      res.status(500).json({
        message: `Se ha producido un error en el  sevidor ${error}`,
      });
    }
  }
}

export const requerimientoController = new RequerimientoController();

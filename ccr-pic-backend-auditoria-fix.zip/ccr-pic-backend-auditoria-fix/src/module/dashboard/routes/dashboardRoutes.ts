import { Router } from "express";
import { authController } from "../../../auth/middleware/auth-middleware";
import { dasboardController } from "../controllers/dasboardController";

class DasboardRoutes {
  public router: Router = Router();

  constructor() {
    this.config();
  }

  config(): void {
    this.router.get(
      "/tipoAuditoriaGAOF",
      //   authController.isAuth,
      dasboardController.getNivelRiesgoDasboardGAOF
    );
    this.router.get(
      "/tipoAuditoriaGAT",
      //   authController.isAuth,
      dasboardController.getNivelRiesgoDasboardGAT
    );
    this.router.get(
      "/riesgoAsociadoGAOF",
      dasboardController.getRiesgoAsociadoGAOF
    );
    this.router.get(
      "/riesgoAsociadoGAT",
      dasboardController.getRiesgoAsociadoGAT
    );
  }
}

const dashboardRoutes = new DasboardRoutes();

export default dashboardRoutes.router;

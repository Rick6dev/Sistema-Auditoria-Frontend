import { Request, Response } from "express";
import Hallazgo from "../../hallazgo/models/HallazgoModel";
import { Sequelize } from "sequelize";

class DasboardController {
  public async getNivelRiesgoDasboardGAOF(
    req: Request,
    res: Response,
  ): Promise<void> {
    try {
      const dashboard = await Hallazgo.findAll({
        attributes: [
          "created_year",
          "id_gerencia_encargada",
          [Sequelize.fn("COUNT", "*"), "total"],
          [
            Sequelize.fn(
              "SUM",
              Sequelize.literal("CASE WHEN id_nivel_riesgo=4 THEN 1 ELSE 0 END")
            ),
            "bajo",
          ],
          [
            Sequelize.fn(
              "SUM",
              Sequelize.literal("CASE WHEN id_nivel_riesgo=3 THEN 1 ELSE 0 END")
            ),
            "medio",
          ],
          [
            Sequelize.fn(
              "SUM",
              Sequelize.literal("CASE WHEN id_nivel_riesgo=2 THEN 1 ELSE 0 END")
            ),
            "alto",
          ],
          [
            Sequelize.fn(
              "SUM",
              Sequelize.literal("CASE WHEN id_nivel_riesgo=1 THEN 1 ELSE 0 END")
            ),
            "critico",
          ],
        ],
        group: ["created_year", "id_gerencia_encargada"],
        order: ["created_year"],
        where: {
          id_gerencia_encargada: 2,
        },
      });

      if (dashboard.length === 0) {
      } else {
        res.status(200).json(dashboard);
      }
    } catch (error) {
      res.status(500).json({
        message: `Se ha producido un error en el servidor. Contactar con el administrador ${error}`,
      });
    }
  }

  public async getNivelRiesgoDasboardGAT(
    req: Request,
    res: Response
  ): Promise<void> {
    try {
      const dashboard = await Hallazgo.findAll({
        attributes: [
          "created_year",
          "id_gerencia_encargada",
          [Sequelize.fn("COUNT", "*"), "total"],
          [
            Sequelize.fn(
              "SUM",
              Sequelize.literal("CASE WHEN id_nivel_riesgo=4 THEN 1 ELSE 0 END")
            ),
            "bajo",
          ],
          [
            Sequelize.fn(
              "SUM",
              Sequelize.literal("CASE WHEN id_nivel_riesgo=3 THEN 1 ELSE 0 END")
            ),
            "medio",
          ],
          [
            Sequelize.fn(
              "SUM",
              Sequelize.literal("CASE WHEN id_nivel_riesgo=2 THEN 1 ELSE 0 END")
            ),
            "alto",
          ],
          [
            Sequelize.fn(
              "SUM",
              Sequelize.literal("CASE WHEN id_nivel_riesgo=1 THEN 1 ELSE 0 END")
            ),
            "critico",
          ],
        ],
        group: ["created_year", "id_gerencia_encargada"],
        order: ["created_year"],
        where: {
          id_gerencia_encargada: 1,
        },
      });

      if (dashboard.length === 0) {
      } else {
        res.status(200).json(dashboard);
      }
    } catch (error) {
      res.status(500).json({
        message: `Se ha producido un error en el servidor. Contactar con el administrador ${error}`,
      });
    }
  }

  public async getRiesgoAsociadoGAT(
    req: Request,
    res: Response
  ): Promise<void> {
    try {
      const dashboard = await Hallazgo.findAll({
        attributes: [
          "created_year",
          "id_gerencia_encargada",
          [Sequelize.fn("COUNT", "*"), "total"],
          [
            Sequelize.fn(
              "SUM",
              Sequelize.literal(
                "CASE WHEN  id_riesgo_asociado=1 THEN 1 ELSE 0 END"
              )
            ),
            "operacional",
          ],
          [
            Sequelize.fn(
              "SUM",
              Sequelize.literal(
                "CASE WHEN id_riesgo_asociado=2  THEN 1 ELSE 0 END"
              )
            ),
            "tecnologico",
          ],
          [
            Sequelize.fn(
              "SUM",
              Sequelize.literal(
                "CASE WHEN id_riesgo_asociado=3 THEN 1 ELSE 0 END"
              )
            ),
            "liquidez",
          ],
          [
            Sequelize.fn(
              "SUM",
              Sequelize.literal(
                "CASE WHEN id_riesgo_asociado=5 THEN 1 ELSE 0 END"
              )
            ),
            "credito",
          ],
          [
            Sequelize.fn(
              "SUM",
              Sequelize.literal(
                "CASE WHEN id_riesgo_asociado=4 THEN 1 Else 0 END"
              )
            ),
            "mercado",
          ],
          [
            Sequelize.fn(
              "SUM",
              Sequelize.literal(
                "CASE WHEN id_riesgo_asociado=6 THEN 1 ELSE 0 END"
              )
            ),
            "reputacional",
          ],
          [
            Sequelize.fn(
              "SUM",
              Sequelize.literal(
                "CASE WHEN id_riesgo_asociado=7 THEN 1 ELSE 0  END "
              )
            ),
            "legal",
          ],
          [
            Sequelize.fn(
              "SUM",
              Sequelize.literal(
                "CASE WHEN id_riesgo_asociado=8 THEN 1 ELSE 0 END"
              )
            ),
            "estrategicos",
          ],
          [
            Sequelize.fn(
              "SUM",
              Sequelize.literal(
                "CASE WHEN id_riesgo_asociado=9 THEN 1 ELSE 0 END"
              )
            ),
            "financiero",
          ],
        ],
        group: ["created_year", "id_gerencia_encargada"],
        order: ["created_year"],
        where: {
          id_gerencia_encargada: 1,
        },
      });

      if (dashboard.length === 0) {
      } else {
        res.status(200).json(dashboard);
      }
    } catch (error) {
      res.status(500).json({
        message: `Se ha  producido  un error  en el  servidor .Contactar con el administrador  ${error}`,
      });
    }
  }

  public async getRiesgoAsociadoGAOF(
    req: Request,
    res: Response
  ): Promise<void> {
    try {
      const dashboard = await Hallazgo.findAll({
        attributes: [
          "created_year",
          "id_gerencia_encargada",
          [Sequelize.fn("COUNT", "*"), "total"],
          [
            Sequelize.fn(
              "SUM",
              Sequelize.literal(
                "CASE WHEN  id_riesgo_asociado=1 THEN 1 ELSE 0 END"
              )
            ),
            "operacional",
          ],
          [
            Sequelize.fn(
              "SUM",
              Sequelize.literal(
                "CASE WHEN id_riesgo_asociado=2  THEN 1 ELSE 0 END"
              )
            ),
            "tecnologico",
          ],
          [
            Sequelize.fn(
              "SUM",
              Sequelize.literal(
                "CASE WHEN id_riesgo_asociado=3 THEN 1 ELSE 0 END"
              )
            ),
            "liquidez",
          ],
          [
            Sequelize.fn(
              "SUM",
              Sequelize.literal(
                "CASE WHEN id_riesgo_asociado=5 THEN 1 ELSE 0 END"
              )
            ),
            "credito",
          ],
          [
            Sequelize.fn(
              "SUM",
              Sequelize.literal(
                "CASE WHEN id_riesgo_asociado=4 THEN 1 Else 0 END"
              )
            ),
            "mercado",
          ],
          [
            Sequelize.fn(
              "SUM",
              Sequelize.literal(
                "CASE WHEN id_riesgo_asociado=6 THEN 1 ELSE 0 END"
              )
            ),
            "reputacional",
          ],
          [
            Sequelize.fn(
              "SUM",
              Sequelize.literal(
                "CASE WHEN id_riesgo_asociado=7 THEN 1 ELSE 0  END "
              )
            ),
            "legal",
          ],
          [
            Sequelize.fn(
              "SUM",
              Sequelize.literal(
                "CASE WHEN id_riesgo_asociado=8 THEN 1 ELSE 0 END"
              )
            ),
            "estrategicos",
          ],
          [
            Sequelize.fn(
              "SUM",
              Sequelize.literal(
                "CASE WHEN id_riesgo_asociado=9 THEN 1 ELSE 0 END"
              )
            ),
            "financiero",
          ],
        ],
        group: ["created_year", "id_gerencia_encargada"],
        order: ["created_year"],
        where: {
          id_gerencia_encargada: 2,
        },
      });

      if (dashboard.length === 0) {
      } else {
        res.status(200).json(dashboard);
      }
    } catch (error) {
      res.status(500).json({
        message: `Se ha  producido  un error  en el  servidor .Contactar con el administrador  ${error}`,
      });
    }
  }
}

export const dasboardController = new DasboardController();

import express, { Application } from "express";
import morgan from "morgan";
import cors from "cors";
import dotenv from 'dotenv';
import adminRoutes from "./routes/adminRoutes";
import informeAuditoriaRoutes from "./module/informeAuditoria/routes/informeAuditoriaRoutes";
import hallazgoAudRoutes from "./module/hallazgo/routes/hallazgoRoutes";
import dashboardRoutes from "./module/dashboard/routes/dashboardRoutes";
import { auditSequelize } from "./database";
import loginRoutes from "./auth/routes/loginRoutes";
import { authController } from "./auth/middleware/auth-middleware";
import * as https from "https";
import * as fs from "fs";
import configData from "./config/configData";
import vacacionRoutes from "./routes/vacacionRoutes";
import planifiicacionRoutes from "./module/planificacion/routes/planifiicacionRoutes";
import requerimientoRoutes from "./module/requerimiento/routes/requerimientoRoutes";
class Server {
  public app: Application;

  constructor() {
    this.app = express();
    this.config();
    // this.connectMainDatabase()
    this.connectAuditDatabase();
    this.routes();
  }

  config(): void {
    this.app.set(
      "port",
      this.normalizePort(process.env.PORT || configData.SERVER.PORT)
    );
    this.app.use(morgan("dev"));
    // Permite pedi los datos  al servidor  por el frontend
    this.app.use(express.json());
    // Permite enviar datos desde datos desde un formulario
    this.app.use(express.urlencoded({ extended: false }));
    this.app.use(cors());
  }

  routes(): void {
    this.app.use("/api/admin", adminRoutes);
    this.app.use(
      "/api/informeAud", authController.isAuth,

      informeAuditoriaRoutes
    );
    this.app.use("/api/hallazgo", authController.isAuth, hallazgoAudRoutes);
    this.app.use("/", loginRoutes);
    this.app.use("/api/vacacion", authController.isAuth, vacacionRoutes);
    this.app.use("/api/planificacion", authController.isAuth, planifiicacionRoutes);
    this.app.use("/api/dashboard", authController.isAuth, dashboardRoutes);
    this.app.use("/api/requerimiento", requerimientoRoutes);
  }

  async connectAuditDatabase() {
    try {
      await auditSequelize.authenticate();
      console.log("Conexion Establecida Bases de  datos  de Auditoria");
      return auditSequelize;
    } catch (error) {
      console.error("Error connecting to audit database:", error);
      throw error;
    }
  }
  start(): void {
    dotenv.config();
    const server = https.createServer(
      {
        key: fs.readFileSync(configData.SERVER.KEY_FILE_PATH),
        cert: fs.readFileSync(configData.SERVER.CERT_FILE_PATH),
      },
      this.app
    );

    process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
    server.listen(this.app.get("port"), () => {
      console.log(`Server on port ${this.app.get("port")}`);
    });
  }

  normalizePort = (val: any) => {
    const port = parseInt(val, 10);
    if (isNaN(port)) {
      return val;
    }
    if (port >= 0) {
      return port;
    }
    return false;
  };
}

const server = new Server();
server.start();

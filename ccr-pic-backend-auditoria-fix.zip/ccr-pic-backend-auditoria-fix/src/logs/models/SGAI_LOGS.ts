import { DataTypes, Sequelize } from "sequelize";
import { auditSequelize } from "../../database";

const SGAI_LOGSModel = auditSequelize.define(
  "SGAI_LOGS",
  {
    id_log: {
      type: DataTypes.INTEGER,
      allowNull: true,
      primaryKey: true,
    },
    ejecutor: {
      type: DataTypes.STRING(200),
      allowNull: false,
    },
    ip_origen: {
      type: DataTypes.STRING(250),
      allowNull: true,
      defaultValue: null,
    },
    ip_destino: {
      type: DataTypes.STRING(250),
      allowNull: true,
      defaultValue: null,
    },
    fecha_ejecucion: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
    },
    id_accion: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
  },
  {
    freezeTableName: true,
    timestamps: false,
  }
);

export default SGAI_LOGSModel;

import SGAI_LOGSModel from "../models/SGAI_LOGS";
import * as jwt from "jsonwebtoken";
export async function createLogs(token: any, id_accion: number): Promise<void> {
  try {
    const options: jwt.DecodeOptions = { complete: true };
    const tokenStruct: any = jwt.decode(token, options);
    await SGAI_LOGSModel.create({
      ejecutor: tokenStruct.payload.userNombre,
      ip_origen: "00.000.00.00",
      ip_destino: "10.132.0.232/10.132.0.56",
      id_accion: id_accion,
    });
  } catch (errro) {
    console.log(errro);
  }
}

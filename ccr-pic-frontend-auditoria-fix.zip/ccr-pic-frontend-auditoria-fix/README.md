# Configuraciòn proyecto Frontend

Este proyecto utiliza la version de Angular version 13.3.11.

## Installation

Con tal de instalar todas las  dependencias requeridas,esperar a que el proceso termine para continuar

```bash
npm install --legacy-peer-deps
```

## Levantar el Sistema en Desarrollo
Levantar el proyecto de forma local  en el ordenador
```bash 
ng serve
```
## Construir el proyecto
Con la  finalidad de construir el proyecto de angular ejecutar el comando

```bash 
ng build
```
## License

Ricardo Torres
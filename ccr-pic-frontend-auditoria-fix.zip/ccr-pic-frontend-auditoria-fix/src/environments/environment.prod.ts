export const environment = {
  production: true,
  // apiUrl: 'https://localhost',
  apiUrl: 'https://10.134.0.167:31981',


};

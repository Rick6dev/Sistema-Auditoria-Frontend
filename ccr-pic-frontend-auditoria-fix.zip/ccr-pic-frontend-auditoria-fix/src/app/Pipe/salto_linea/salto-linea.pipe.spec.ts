import { SaltoLineaPipe } from './salto-linea.pipe';

describe('SaltoLineaPipe', () => {
  it('create an instance', () => {
    const pipe = new SaltoLineaPipe();
    expect(pipe).toBeTruthy();
  });
});

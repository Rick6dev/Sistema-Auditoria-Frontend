import { BackgroundPipe } from './background.pipe';

describe('BackgroundPipe', () => {
  it('create an instance', () => {
    const pipe = new BackgroundPipe();
    expect(pipe).toBeTruthy();
  });
});

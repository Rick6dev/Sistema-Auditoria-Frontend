import { FechaNormalPipe } from './fecha-normal.pipe';

describe('FechaNormalPipe', () => {
  it('create an instance', () => {
    const pipe = new FechaNormalPipe();
    expect(pipe).toBeTruthy();
  });
});

import { FechaFormatPipe } from './fecha-format.pipe';

describe('FechaFormatPipe', () => {
  it('create an instance', () => {
    const pipe = new FechaFormatPipe();
    expect(pipe).toBeTruthy();
  });
});

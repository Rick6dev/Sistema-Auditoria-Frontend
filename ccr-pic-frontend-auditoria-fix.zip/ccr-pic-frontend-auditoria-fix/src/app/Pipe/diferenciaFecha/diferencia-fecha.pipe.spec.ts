import { DiferenciaFechaPipe } from './diferencia-fecha.pipe';

describe('DiferenciaFechaPipe', () => {
  it('create an instance', () => {
    const pipe = new DiferenciaFechaPipe();
    expect(pipe).toBeTruthy();
  });
});

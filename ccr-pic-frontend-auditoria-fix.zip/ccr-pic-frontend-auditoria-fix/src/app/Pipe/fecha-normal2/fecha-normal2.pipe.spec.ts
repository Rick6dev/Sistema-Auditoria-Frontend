import { FechaNormal2Pipe } from './fecha-normal2.pipe';

describe('FechaNormal2Pipe', () => {
  it('create an instance', () => {
    const pipe = new FechaNormal2Pipe();
    expect(pipe).toBeTruthy();
  });
});

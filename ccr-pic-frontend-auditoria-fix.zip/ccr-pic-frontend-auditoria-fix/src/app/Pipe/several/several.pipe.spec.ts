import { SeveralPipe } from './several.pipe';

describe('SeveralPipe', () => {
  it('create an instance', () => {
    const pipe = new SeveralPipe();
    expect(pipe).toBeTruthy();
  });
});

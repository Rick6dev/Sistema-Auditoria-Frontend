import { FechaInformePipe } from './fecha-informe.pipe';

describe('FechaInformePipe', () => {
  it('create an instance', () => {
    const pipe = new FechaInformePipe();
    expect(pipe).toBeTruthy();
  });
});

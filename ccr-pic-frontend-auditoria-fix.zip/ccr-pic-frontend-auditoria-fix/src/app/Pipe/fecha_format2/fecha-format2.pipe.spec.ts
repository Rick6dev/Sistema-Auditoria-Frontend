import { FechaFormat2Pipe } from './fecha-format2.pipe';

describe('FechaFormat2Pipe', () => {
  it('create an instance', () => {
    const pipe = new FechaFormat2Pipe();
    expect(pipe).toBeTruthy();
  });
});

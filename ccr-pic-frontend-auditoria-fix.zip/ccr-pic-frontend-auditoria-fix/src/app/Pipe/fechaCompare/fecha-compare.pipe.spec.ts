import { FechaComparePipe } from './fecha-compare.pipe';

describe('FechaComparePipe', () => {
  it('create an instance', () => {
    const pipe = new FechaComparePipe();
    expect(pipe).toBeTruthy();
  });
});

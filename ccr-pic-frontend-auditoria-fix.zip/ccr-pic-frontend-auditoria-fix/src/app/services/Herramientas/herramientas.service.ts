import { Injectable } from '@angular/core';
import { PDFDocument } from 'pdf-lib';
import * as mammoth from 'mammoth';
import { saveAs } from 'file-saver';
@Injectable({
  providedIn: 'root'
})
export class HerramientasService {

  constructor() { }

  async convertPdfToWord(pdfFile: File): Promise<void> {
    try {
      // Leer el archivo PDF
      const pdfBytes = await pdfFile.arrayBuffer();
      const pdfDoc = await PDFDocument.load(pdfBytes);

      // Extraer el texto del PDF
      const pages = pdfDoc.getPages();
      let extractedText = '';



      // Convertir el texto a DOCX usando Mammoth
      const result = await mammoth.extractRawText({ arrayBuffer: pdfBytes });
      const docxContent = result.value;

      // Crear un Blob y guardar el archivo DOCX
      const blob = new Blob([docxContent], { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
      saveAs(blob, 'converted-file.docx');
    } catch (error) {
      console.error('Error converting PDF to Word:', error);
      throw error;
    }
  }
}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modal-borrar',
  templateUrl: './modal-borrar.component.html',
  styleUrls: ['./modal-borrar.component.css']
})
export class ModalBorrarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

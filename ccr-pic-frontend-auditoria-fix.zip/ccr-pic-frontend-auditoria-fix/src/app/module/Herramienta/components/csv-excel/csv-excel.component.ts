import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-csv-excel',
  templateUrl: './csv-excel.component.html',
  styleUrls: ['./csv-excel.component.css']
})
export class CsvExcelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CsvExcelRoutingModule } from './csv-excel-routing.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule, CsvExcelRoutingModule
  ]
})
export class CsvExcelModule { }

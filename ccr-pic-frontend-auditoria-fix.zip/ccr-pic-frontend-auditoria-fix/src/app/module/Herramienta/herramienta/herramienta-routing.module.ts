import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { HerramientaComponent } from "./herramienta.component";

const routes: Routes = [{ path: '', component: HerramientaComponent }]

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})

export class HerramientaRoutingModule { }


import { Component, OnInit } from '@angular/core';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { HerramientasService } from 'src/app/services/Herramientas/herramientas.service';
@Component({
  selector: 'app-herramienta',
  templateUrl: './herramienta.component.html',
  styleUrls: ['./herramienta.component.css']
})
export class HerramientaComponent implements OnInit {

  constructor(private pdfToWordService: HerramientasService) { }

  onFileSelected(event: any): void {
    console.log("Entre")
    const file: File = event.target.files[0];
    if (file) {
      this.pdfToWordService.convertPdfToWord(file).then(() => {
        console.log('File converted successfully!', file);
      });
    }
  }

  ngOnInit(): void {
    console.log("dd");
  }
  flagCSV: boolean = false;
  flagAccept: boolean = false;
  flagProcces: boolean = false;
  flagPDF: boolean = false;

  nombreArchivo: string = '';
  changeState() {
    this.flagCSV = !this.flagCSV;
    this.flagProcces = !this.flagProcces
  }

  reset() {
    this.flagCSV = false;
    this.flagAccept = false;
    this.flagProcces = false;
  }

  changeStatePDF() {
    this.flagPDF = !this.flagCSV;
    this.flagProcces = !this.flagProcces
  }


  csvData: any[] = [];

  // Método para manejar la carga del archivo CSV
  onFileChange(event: any): void {

    const file = event.target.files[0];
    if (file) {
      this.flagAccept = true;
      this.flagProcces = true;
      const fileNameWithExtension = file.name;
      this.extractName(fileNameWithExtension);
      const reader = new FileReader();
      reader.onload = (e: any) => {
        const data = e.target.result;
        this.csvData = this.csvToArray(data);
      };
      reader.readAsText(file);
    } else {
      this.flagAccept = false;
    }
  }


  extractName(name: string) {
    const lastDotIndex = name.lastIndexOf('.');

    this.nombreArchivo = lastDotIndex > 0
      ? name.substring(0, lastDotIndex)
      : name;
  }
  // Método para convertir CSV a un array de objetos
  csvToArray(csv: string): any[] {
    const lines = csv.split('\n');
    const result = [];
    const headers = lines[0].split(';');

    for (let i = 1; i < lines.length; i++) {
      const obj: any = {};
      const currentLine = lines[i].split(';');

      for (let j = 0; j < headers.length; j++) {
        obj[headers[j]] = currentLine[j];
      }
      result.push(obj);
    }
    return result;
  }

  // Método para convertir el array de objetos a Excel
  convertToExcel(): void {
    if (this.csvData.length > 0) {
      const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(this.csvData);
      const workbook: XLSX.WorkBook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
      const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
      this.saveAsExcelFile(excelBuffer, `${this.nombreArchivo}`);
    }
  }

  // Método para guardar el archivo Excel
  saveAsExcelFile(buffer: any, fileName: string): void {
    const data: Blob = new Blob([buffer], { type: 'application/octet-stream' });
    saveAs(data, `${fileName}.xlsx`);
  }

}

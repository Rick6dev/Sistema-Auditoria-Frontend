import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HerramientaRoutingModule } from './herramienta-routing.module';
import { CsvExcelComponent } from '../components/csv-excel/csv-excel.component';
import { CsvExcelModule } from '../components/csv-excel/csv-excel.module';



@NgModule({
  declarations: [
    CsvExcelComponent // Declara el componente aquí
  ],
  imports: [
    CommonModule, HerramientaRoutingModule
  ]
})
export class HerramientaModule { }

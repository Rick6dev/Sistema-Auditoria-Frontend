import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loader-barra',
  templateUrl: './loader-barra.component.html',
  styleUrls: ['./loader-barra.component.css']
})
export class LoaderBarraComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
